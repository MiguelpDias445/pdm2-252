// TODO(CodelabUser): Create an OAuth App
const githubClientId = 'Ov23lim1YVXfvzZrQVRt';
const githubClientSecret = '1388a37188e0684847d02bcd9db2e9b6abbdec4d';

// OAuth scopes for repository and user information
const githubScopes = ['repo', 'read:org'];