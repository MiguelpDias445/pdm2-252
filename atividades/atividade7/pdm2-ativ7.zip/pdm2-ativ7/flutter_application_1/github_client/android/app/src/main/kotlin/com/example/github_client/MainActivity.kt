package com.example.github_client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
